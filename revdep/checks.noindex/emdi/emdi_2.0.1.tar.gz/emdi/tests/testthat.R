library(testthat)
library(emdi)

test_check("emdi")
